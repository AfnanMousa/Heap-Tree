package eg.edu.alexu.csd.filestructure.sort;

import java.util.ArrayList;

public class Sort implements ISort {

    @Override
    public IHeap heapSort(ArrayList unordered) {
        IHeap heap = new Heap();
        ArrayList<Comparable> ans = new ArrayList<>();
        if (unordered != null) {
            int n = unordered.size();
            heap.build(unordered);
            ((Heap) heap).sortExtract();
        }
        return heap;
    }
    @Override
    public void sortSlow(ArrayList unordered) {
        if(unordered!=null){
            Comparable x1 = null;
            Comparable x2=null;
            int min;
            for(int i=0;i<unordered.size();i++){
                min=i;
                x1= (Comparable) unordered.get(i);
                for(int j=i+1;j<unordered.size();j++){
                    x2= (Comparable) unordered.get(j);
                    if (x1.compareTo(x2)>0)
                    {
                        x1=x2;
                        min=j;

                    }
                }
                if (min!=i){
                    Comparable temp1=(Comparable) unordered.get(i);
                    Comparable temp2=(Comparable) unordered.get(min);
                    unordered.remove(i);
                    unordered.add(i,temp2);
                    unordered.remove(min);
                    unordered.add(min,temp1);
                }
            }
        }
        else  return;
    }

    @Override
    public void sortFast(ArrayList unordered) {
        if(unordered!=null){
            merge( unordered,  0, unordered.size()-1);
        }
        else return ;
    }
    private void merge(ArrayList unordered, int Left, int Right){
        if(Left<Right)  {
            int mid=(Left+Right)/2;
            merge(unordered,Left,mid);
            merge(unordered,mid+1,Right);
            MergeSort(unordered,Left,mid,Right);
        }
    }



    private void MergeSort(ArrayList unordered, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;
        ArrayList L = new ArrayList();
        ArrayList R = new ArrayList();
        for (int i = 0; i < n1; ++i)
            L.add(i, unordered.get(l + i));
        for (int j = 0; j < n2; ++j)
            R.add(j, unordered.get(m + 1 + j));
        int i = 0, j = 0;
        int k = l;
        while (i < n1 && j < n2) {
            if (((Comparable) L.get(i)).compareTo(R.get(j)) <= 0) {
                unordered.set(k, L.get(i));
                i++;
            } else {
                unordered.set(k, R.get(j));
                j++;
            }
            k++;
        }
        while (i < n1) {
            unordered.set(k, L.get(i));
            i++;
            k++;
        }
        while (j < n2) {
            unordered.set(k, R.get(j));
            j++;
            k++;
        }
    }

}
