package eg.edu.alexu.csd.filestructure.sort;

public class Node implements INode {
    private Comparable Value;
    private static INode arr[];
    private  int i;
    public Node(int i, INode[] arr){
        this.i=i;
        this.arr=arr;
    }
    @Override
    public INode getLeftChild() {
        try {
            if(arr[2*i+1]!=null) {

                return arr[2*i+1];

            }
        }
        catch(NullPointerException e)
        {
            throw e;
        }
        return null;
    }

    @Override
    public INode getRightChild() {
        try {
            if(arr[2*i+2]!=null) {
                return arr[2*i+2];
            }
        }
        catch(NullPointerException e)
        {
            throw e;
        }
        return null;
    }

    @Override
    public INode getParent() {
        if(i!=0){
            int t=(i-1)/2;
            return arr[t];
        }
        return null;
    }

    @Override
    public Comparable getValue() {
        if(this.Value==null ){
            return arr[i].getValue();
        }
        else
        {
            return this.Value;
        }

    }

    @Override
    public void setValue(Comparable value) {
        this.Value = value;
    }
}
