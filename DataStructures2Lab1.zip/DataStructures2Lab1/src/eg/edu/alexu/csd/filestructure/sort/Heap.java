package eg.edu.alexu.csd.filestructure.sort;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Heap<T> implements IHeap {
    int max=100000000;
    INode[] array=new INode[max];
    private List<INode> heap = new ArrayList<>();
    INode Heap ;
    int bound;

    Heap (INode[] array) {
        this.array=array;
    }
    Heap () {
    }
    @Override
    public INode getRoot() {
        INode root=null;
        if(bound!=0){
            root=array[0];
        }
        return  root;
    }

    @Override
    public int size() {
        return bound;
    }
    int x;
    int z;
    int r;
    int ex;
    @Override
    public void heapify(INode node) {
        if (node!=null) {
            INode L = node.getLeftChild();
            INode R = node.getRightChild();
            INode largest;
            if ((L!=null)&&(L.getValue().compareTo(node.getValue())>0)&&(2*r+1<bound)) {
                largest=L;
                z=2*r+1;
            }else {
                largest=node;
            }if((R!=null)&&(R.getValue().compareTo(largest.getValue())>0)&&(2*r+2<bound)) {
                largest=R;
                z=2*r+2;
            }
            if (largest!=node) {
                Comparable t=node.getValue();
                Comparable t2=largest.getValue();
                largest.setValue(t);
                array[r].setValue(t2);
                r=z;
                node=largest;
                if (ex==1) {
                    x=z;
                }
                heapify(largest);
            }
        }else {
            try {
            }
            catch(NullPointerException e)
            {
                throw e;
            }
        }
    }

    @Override
    public Comparable extract(){
        Comparable max = null;
        if (bound>0) {
            max = this.getRoot().getValue();
            int i=0;
            array[0].setValue(array[bound-1].getValue());
            array[bound-1].setValue(max);;
            bound--;
            Comparable[] arr=new Comparable[2];
            x=0;
            z=0;
            r=0;
            ex=1;
            heapify(array[0]);

        }else {
            try {
            }
            catch(NullPointerException e)
            {
                throw e;
            }
        }
        return max;
    }
    private INode[] swap(INode[] array,Comparable[] arr,int i) {
        Comparable temp = array[i].getValue();
        array[i].setValue(arr[0]);
        array[(int)(arr[1])].setValue(temp);
        return array;
    }
    private Comparable [] maxChild (Comparable a,Comparable b,int i) {
        Comparable[] arr = new Comparable[2] ;
        if((a.compareTo(b)>0)||(((2*i+2>bound-1)&&(i!=-1)))&&(bound!=0)) {
            arr[0]= a;
            arr[1]=2*i+1;
        }else {
            arr[0]= b;
            arr[1]=2*i+2;
        }
        return arr;
    }

    @Override
    public void insert(Comparable element) {
        if(element!=null){
            INode node1 = new Node(bound,array);
            node1.setValue(element);
            array[bound]=node1;
            bound++;
            ResetValue(array);
            Heap=new Node(0,array);
        }
    }


    @Override
    public void build(Collection unordered) {
        if (unordered!=null) {
            int n=unordered.size();
            //         ArrayList<Comparable> arr = new ArrayList <Comparable>(unordered);
            Comparable[] temp = new Comparable[unordered.size()];
            unordered.toArray(temp);
            bound=unordered.size();
            INode[] arr=new Node[unordered.size()];
            for (int i=0;i<n;i++) {
                array[i]=new Node(i,array);
                if(i!=0) {
                }
                array[i].setValue(temp[i]);
            }
            for (x =  n/ 2 - 1; x >= 0; x--) {
                z=x;
                r=x;
                heapify(array[x]);
            }
        }else {
            try {
            }
            catch(NullPointerException e)
            {
                throw e;
            }
        }
    }
    public void sortExtract(){
        if (bound==0) {
            return;
        }
        for (int i = array.length - 1; i >= 0; i--) {
            extract();
        }
        bound = heap.size()-1;
    }

    private void ResetValue(INode[] OldArray){
        for (int i=bound-1;i>0;){
            INode parent =new Node(((i-1)/2),OldArray);
            INode Child =new Node(i,OldArray);
            if(parent.getValue().compareTo(Child.getValue())<0){
                Comparable x=parent.getValue();
                OldArray[(i-1)/2].setValue(Child.getValue());
                OldArray[i].setValue(x);
                i=((i-1)/2);
            }
            else {
                break;
            }
        }
    }
}