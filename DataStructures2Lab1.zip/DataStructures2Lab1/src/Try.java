import eg.edu.alexu.csd.filestructure.sort.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

public class Try {

    public static void main(String[] args) {

        LinkedList<ArrayList<Integer>> Input=new LinkedList<ArrayList<Integer>>();
        ArrayList<Integer> array1 = new ArrayList();
        ArrayList<Integer> array2 = new ArrayList();
        ArrayList<Integer> array3 = new ArrayList();
        ArrayList<Integer> array4 = new ArrayList();
        ArrayList<Integer> array5 = new ArrayList();
       // System.out.print("Slow Sort time"+" "+"  ");
        for(int i=0;i<10;i++){
            Random r = new Random();
            int val = r.nextInt(1000);
            array1.add(val);
        }
        for(int i=0;i<100;i++){
            Random r = new Random();
            int val = r.nextInt(1000);
            array2.add(val);
        }

        for(int i=0;i<1000;i++){
            Random r = new Random();
            int val = r.nextInt(1000);
            array3.add(val);
        }

        for(int i=0;i<10000;i++){
            Random r = new Random();
            int val = r.nextInt(1000);
            array4.add(val);
        }

        for(int i=0;i<100000;i++){
            Random r = new Random();
            int val = r.nextInt(1000);
            array5.add(val);
        }
        Input.add(array1);
        Input.add(array2);
        Input.add(array3);
        Input.add(array4);
        Input.add(array5);
        ISort heap1=new Sort();
        System.out.println();
        System.out.print("Slow Sort time");
        for(int i=0;i<Input.size();i++){
            long startTime = System.nanoTime();
            heap1.sortSlow(Input.get(i));
            long endTime = System.nanoTime();
            System.out.print(" "+(endTime-startTime)+"  ");
        }
        System.out.println();
        System.out.print("Fast Sort time");
        for(int i=0;i<Input.size();i++){
            long startTime = System.nanoTime();
            heap1.sortFast(Input.get(i));
            long endTime = System.nanoTime();
            System.out.print(" "+(endTime-startTime)+"  ");
        }
        System.out.println();
           /* System.out.print("Heap Sort time");
        for(int i=0;i<Input.size();i++){
            long startTime = System.nanoTime();
            heap1.heapSort(Input.get(i));
            long endTime = System.nanoTime();
            System.out.print(" "+(endTime-startTime)+"  ");
        }*/

    }
}
